package listaArray;

import java.util.ArrayList;
import java.util.List;


public class qst14 {

	public static void main(String[] args) {
		ArrayList<Integer> inteiro = new ArrayList <>();
		ArrayList<Integer> inteiro2 = new ArrayList <>();
		
		inteiro.add(1);
		inteiro.add(2);
		inteiro.add(3);
		
		inteiro2.add(3);
		inteiro2.add(2);
		inteiro2.add(1);
		
		System.out.println(" As listas são iguais? " + inteiro.equals(inteiro2));
		
		
	}

}
