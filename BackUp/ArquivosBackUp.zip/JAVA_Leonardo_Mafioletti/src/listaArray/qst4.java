package listaArray;

import java.util.ArrayList;
import java.util.List;


public class qst4 {

	public static void main(String[] args) {
		ArrayList<String> nome = new ArrayList<>();
		
		nome.add("Ana");
		nome.add("Bruno");
		nome.add("Carlos");
		nome.add("Diana");
		nome.add("Eduardo");
		
		
			System.out.println("Carlos está na lista? " + nome.contains("Carlos"));
			
			System.out.println("Diana está no indice: " + nome.indexOf("Diana") );
			
			System.out.println("Felipe esta em algum indice? " + nome.indexOf("Felipe")); //resultado é -1 porque não tem felipe na lista.
			
		}
	}


