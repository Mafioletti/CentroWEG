package listaArray;

import java.util.ArrayList;
import java.util.List;



public class qst1 {

	public static void main(String[] args) {

		ArrayList<String> frutas = new ArrayList <>();
		
		frutas.add("Maçã");
		frutas.add("Banana");
		frutas.add("Uva");
		frutas.add("Pera");
		frutas.add("Goiaba");
		
		System.out.println("O tamanho da lista é: " + frutas.size());
		
		for (String i : frutas) {
			System.out.println(i);
		}
		
	}

}
