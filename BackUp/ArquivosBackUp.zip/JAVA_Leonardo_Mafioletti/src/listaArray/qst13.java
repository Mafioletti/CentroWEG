package listaArray;

import java.util.ArrayList;
import java.util.List;


public class qst13 {

	public static void main(String[] args) {
		ArrayList<Integer> inteiro = new ArrayList <>();
		
		inteiro.add(10);
		inteiro.add(9);
		inteiro.add(8);
		
		System.out.println(" A lista está vazia? " + inteiro.isEmpty());
	}

}
