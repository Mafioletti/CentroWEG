package listaArray;

import java.util.ArrayList;
import java.util.List;


public class qst2 {

	public static void main(String[] args) {
		ArrayList<String> semana = new ArrayList <>();
		
		semana.add("Domingo");
		semana.add("Segunda");
		semana.add("Terça");
		semana.add("Quarta");
		semana.add("Quinta");
		semana.add("Sexta");
		semana.add("Sábado");
		
		System.out.println("O terceiro elemento é: " + semana.get(2));
		semana.set(5, "Sexta-Feira");
		System.out.println("O quinto elemento é: " + semana.get(5));
		
		
	}

}
