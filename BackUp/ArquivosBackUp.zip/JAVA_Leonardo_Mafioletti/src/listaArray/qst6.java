package listaArray;

import java.util.ArrayList;
import java.util.List;


public class qst6 {

	public static void main(String[] args) {
		ArrayList <String> cidade = new ArrayList <>();
		
		cidade.add("São Paulo");
		cidade.add("RJ");
		cidade.add("Belo H");
		cidade.add("cwb");
		
		for(int i = 0; i <= cidade.size(); i++) {
			System.out.println("Posição:" + i + " \tCidade:" + cidade.get(i) + "");
		}
		
	}

}
