package listaArray;

import java.util.ArrayList;
import java.util.List;


public class qst12 {

	public static void main(String[] args) {
		ArrayList <String> fruta = new ArrayList<>();
		
		fruta.add("Maçã");
		fruta.add("Uva");
		fruta.add("Pera");
		
		System.out.println("Lista: " + fruta);
		
		fruta.clear();
		
		
		System.out.println("Lista: " + fruta);
	}

}
