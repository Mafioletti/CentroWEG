package listaArray;

import java.util.ArrayList;
import java.util.List;


public class qst10 {

	public static void main(String[] args) {
		ArrayList<Integer> num = new ArrayList <>();
		ArrayList<Integer> num2 = new ArrayList <>();
		
		num.add(1);
		num.add(2);
		num.add(3);
		num.add(4);
		num.add(5);
		
		System.out.println("Lista 1: " + num);
		
		num2.add(6);
		num2.add(7);
		num2.add(8);
		num2.add(9);
		num2.add(10);
		
		System.out.println("Lista 2: " + num2);
		
		num.addAll(num2);
		
		System.out.println("Lista juntas: " + num);
		
		
		
	}

}
