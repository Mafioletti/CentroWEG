package listaArray;

import java.util.ArrayList;
import java.util.List;


public class qst3 {

	public static void main(String[] args) {
		ArrayList<Integer> numeros = new ArrayList <>();
		
		numeros.add(10);
		numeros.add(20);
		numeros.add(30);
		numeros.add(40);
		numeros.add(50);
		
		numeros.remove(2);
		
		System.out.println(numeros);
	}

}
