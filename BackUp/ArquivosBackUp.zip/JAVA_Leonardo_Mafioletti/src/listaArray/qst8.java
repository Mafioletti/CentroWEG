package listaArray;

import java.util.ArrayList;
import java.util.List;


public class qst8 {

	public static void main(String[] args) {
		
		ArrayList<String> fruta = new ArrayList <>();
		
		fruta.add("Uva");
		fruta.add("Pera");
		fruta.add("Maçã");
		fruta.add("Goiaba");
		
		System.out.println(fruta);
		
		fruta.add(1, "Banana");
		fruta.add(3, "Laranja");
		
		System.out.println(fruta);
	}

}
