package listaArray;
import java.util.ArrayList;
import java.util.List;


public class qst9 {

	public static void main(String[] args) {
		
		ArrayList<Integer> num = new ArrayList <>();
		
		num.add(100);
		num.add(200);
		num.add(300);
		num.add(400);
		num.add(500);
		
		System.out.println("O tamanho da lista é: " + num.size());
		
		num.add(600);
		
		System.out.println("Agora o tamanho é: " + num.size());
	}

}
