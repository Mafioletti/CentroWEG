package listaArray;

import java.util.ArrayList;
import java.util.List;


public class qst7 {

	public static void main(String[] args) {
		
		ArrayList<Integer> num = new ArrayList <>();
	
		num.add(1);
		num.add(2);
		num.add(3);
		num.add(4);
		num.add(5);
		num.add(6);
		
		num.remove(2);
		System.out.println(num);
	
	}

}
