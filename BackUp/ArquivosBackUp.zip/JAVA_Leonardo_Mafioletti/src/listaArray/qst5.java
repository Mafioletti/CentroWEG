package listaArray;

import java.util.ArrayList;
import java.util.List;


public class qst5 {

	public static void main(String[] args) {

		ArrayList<Double> decimais = new ArrayList <>();
		
		decimais.add(10.5);
		decimais.add(9.5);
		decimais.add(8.5);
		decimais.add(12.5);
		decimais.add(15.5);
		
		System.out.println("Valores da lista: " + decimais);
		
		double soma = 0.0;
		
		for(Double i: decimais) {
			soma += i;
			
			
		}
		System.out.println(" O valor Total é: " + soma);
	}

}
