package listaArray;

import java.util.ArrayList;
import java.util.List;


public class qst11 {

	public static void main(String[] args) {
		ArrayList <String> nome = new ArrayList <>();
		
		nome.add("Alice");
		nome.add("Bob");
		nome.add("Carol");
		nome.add("David");
		nome.add("Eve");
		
		System.out.println(nome);
		
		nome.set(2, "Carlos");
		
		System.out.println(nome);
		
			
	}

}
