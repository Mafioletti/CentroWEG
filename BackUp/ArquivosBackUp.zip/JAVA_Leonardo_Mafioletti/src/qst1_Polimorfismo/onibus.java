package qst1_Polimorfismo;

public class onibus extends transporte{
	private int numeroLinhas;

	public onibus(double distancia, int passageiros, int numeroLinhas) {
		super(distancia, passageiros);
		this.numeroLinhas = numeroLinhas;
	}
	public int getNumeroLinhas() {
		return numeroLinhas;
	}

	public void setNumeroLinhas(int numeroLinhas) {
		this.numeroLinhas = numeroLinhas;
	}

	//Método
	@Override
	public double calcularCusto() {
		return getDistancia() * 0.80;
	}
	@Override
	public void exibirDetalhes() {
		super.exibirDetalhes();
		System.out.println("Número de Linhas: " + numeroLinhas);
		}
	}

