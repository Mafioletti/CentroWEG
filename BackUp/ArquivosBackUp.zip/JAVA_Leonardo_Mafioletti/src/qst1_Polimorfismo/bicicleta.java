package qst1_Polimorfismo;

public class bicicleta extends transporte{
	private String tipoFreio;

	public bicicleta(double distancia, int passageiros, String tipoFreio) {
		super(distancia, passageiros);
		this.tipoFreio = tipoFreio;
	}

	public String getTipoFreio() {
		return tipoFreio;
	}

	public void setTipoFreio(String tipoFreio) {
		this.tipoFreio = tipoFreio;
	}
	
	@Override
	public double calcularCusto() {
		return getDistancia() * 0;
	}
	
	@Override
	public void exibirDetalhes() {
		super.exibirDetalhes();
		System.out.println("Tipo do Freio: " + tipoFreio);
	}
}
