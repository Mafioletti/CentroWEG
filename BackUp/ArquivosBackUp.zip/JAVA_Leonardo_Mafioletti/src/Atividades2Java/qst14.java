package Atividades2Java;

import java.util.*;

public class qst14 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		System.out.println("Digite o capital inicial");
		double capitalInicial = input.nextInt();
		System.out.println("Digite a taxa de juros");
		double taxaJuros = input.nextInt();
		System.out.println("Digite o tempo");
		double tempo = input.nextInt();

		double montante = calcularMontante(capitalInicial, taxaJuros, tempo);
		double lucro = calcularLucro(montante, capitalInicial);

		System.out.println("O valor final é: " + montante + "R$\nLucro de : " + lucro + "R$");

		input.close();

	}

	public static double calcularMontante(double capital, double taxa, double tempo) {
		double montante = capital * Math.pow(1 + (taxa / 100), tempo);

		return montante;
	}

	public static double calcularLucro(double capital, double montante) {
		double lucro = montante - capital;
		if (lucro < 0) {
			lucro *= -1;
		}
		return lucro;
	}
}