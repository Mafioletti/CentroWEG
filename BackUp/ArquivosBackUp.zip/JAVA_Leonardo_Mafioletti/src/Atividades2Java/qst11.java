package Atividades2Java;

import java.util.Scanner;

public class qst11 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		for (int i = 1; i <= 4; i++) {
			System.out.println("Digite a quantidade produzida");
			double qtdProduzida = input.nextInt();
			System.out.println("Digite a quantidade defeituosa");
			double qtdDefeituosa = input.nextInt();

			double totalDeDefeitos = calcularTaxaDefeito(qtdProduzida, qtdDefeituosa);
			String classificacaoDoTurno = classificarTurno(totalDeDefeitos);

			System.out.println("A taxa de defeitos do turno " + i + " foi de: " + totalDeDefeitos
					+ "%, classificação do turno: " + classificacaoDoTurno);
		}
		input.close();

	}

	public static double calcularTaxaDefeito(double totalProduzido, double defeituosos) {
		double taxa = (defeituosos / totalProduzido) * 100;
		return taxa;
	}

	public static String classificarTurno(double taxa) {
		if (taxa < 2) {
			return "Excelente";
		} else if (taxa >= 2 && taxa <= 5) {
			return "Boa";
		} else {
			return "Crítica";
		}
	}
}