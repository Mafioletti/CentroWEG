package Atividades2Java;

import java.util.Scanner;

public class qst13 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		System.out.println("Digite a porcentagem de uso da CPU");
		double usoCPU = input.nextInt();
		System.out.println("Digite a porcentagem de uso da memória");
		double usoMemoria = input.nextInt();
		System.out.println("Digite a porcentagem de uso do disco");
		double usoDisco = input.nextInt();

		double mediaDoUso = calcularMediaUso(usoCPU, usoMemoria, usoDisco);
		String classificacaoDoServidor = classificarServidor(mediaDoUso);

		System.out
				.println("A media do uso é: " + mediaDoUso + ", classificação do servidor: " + classificacaoDoServidor);

		input.close();

	}

	public static double calcularMediaUso(double cpu, double memoria, double disco) {
		int media = 0;
		media += cpu;
		media += memoria;
		media += disco;

		media /= 3;

		return media;
	}

	public static String classificarServidor(double mediaUso) {
		if (mediaUso < 50) {
			return "Normal";
		} else if (mediaUso >= 50 && mediaUso <= 80) {
			return "Atenção";
		} else {
			return "Crítico";
		}
	}
}