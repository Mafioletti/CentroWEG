package Atividades2Java;

import java.util.Scanner;

public class qst12 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		System.out.println("Digite a quantidade inicial do estoque");
		int inicial = input.nextInt();
		System.out.println("Digite a quantidade que entrou no estoque");
		int entrada = input.nextInt();
		System.out.println("Digite a quantidade que saiu do estoque");
		int saida = input.nextInt();

		int estoqueFinal = calcularEstoqueFinal(inicial, entrada, saida);
		String classificacaoEstoque = verificarNivelEstoque(estoqueFinal);

		System.out.println(
				"O estoque final é de: " + estoqueFinal + ", classificação do estoque: " + classificacaoEstoque);

		input.close();

	}

	public static int calcularEstoqueFinal(int estoqueInicial, int entradas, int saidas) {
		estoqueInicial += entradas;
		estoqueInicial -= saidas;
		return estoqueInicial;
	}

	public static String verificarNivelEstoque(int estoque) {
		if (estoque < 50) {
			return "Baixo";
		} else if (estoque >= 50 && estoque <= 200) {
			return "Adequado";
		} else {
			return "Alto";
		}
	}
}