package EncapsulamentoDede;

public class aluno {
	    private String nome;
	    private double nota1;
	    private double nota2;

	    public aluno(String nome, double nota1, double nota2) {
	        this.nome = nome;
	        this.nota1 = nota1;
	        this.nota2 = nota2;
	    }

	    public String getNome() {
	        return nome;
	    }

	    public void setNome(String nome) {
	        this.nome = nome;
	    }

	    public double getNota1() {
	        return nota1;
	    }

	    public void setNota1(double nota1) {
	        this.nota1 = nota1;
	    }

	    public double getNota2() {
	        return nota2;
	    }

	    public void setNota2(double nota2) {
	        this.nota2 = nota2;
	    }

	    public double calcularMedia() {
	        return (nota1 + nota2) / 2;
	    }

	    public void mostrarSituacao() {
	        double media = calcularMedia();
	        String situacao = (media >= 7.0) ? "Aprovado" : "Reprovado";
	        System.out.println("Aluno: " + nome);
	        System.out.println("Média: " + media);
	        System.out.println("Situação: " + situacao);
	    }

	    public static void main(String[] args) {
	        aluno aluno1 = new aluno("Mafioletti", 8.5, 6.0);
	        aluno1.mostrarSituacao();
	    }
	}