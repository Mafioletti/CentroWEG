package EncapsulamentoDede;

public class contaBancaria {
    private String titular;
    private double saldo;

    public contaBancaria(String titular, double saldo) {
        this.titular = titular;
        this.saldo = saldo;
    }

    public String getTitular() {
        return titular;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public void depositar(double valor) {
        if (valor > 0) {
            this.saldo += valor;
        }
    }

    public void sacar(double valor) {
        if (valor > 0 && valor <= this.saldo) {
            this.saldo -= valor;
        } else {
            System.out.println("Saque negado: Saldo insuficiente ou valor inválido.");
        }
    }

    public void mostrarSaldo() {
        System.out.println("Titular: " + titular + " \nSaldo atual: R$ " + saldo);
    }

    public static void main(String[] args) {
        contaBancaria minhaConta = new contaBancaria("Leonardo Mafioletti", 1000.00);

        minhaConta.depositar(500.00);
        minhaConta.sacar(200.00);
        
        minhaConta.mostrarSaldo();
    }
}