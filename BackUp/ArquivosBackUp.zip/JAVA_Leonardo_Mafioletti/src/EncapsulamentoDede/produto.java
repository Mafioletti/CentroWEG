package EncapsulamentoDede;

public class produto {
    private String nome;
    private double preco;
    private int quantidade;

    public produto(String nome, double preco, int quantidade) {
        this.nome = nome;
        this.preco = preco;
        this.quantidade = quantidade;
    }

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public double getPreco() {
		return preco;
	}

	public void setPreco(double preco) {
		this.preco = preco;
	}

	public int getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}
	public void exibirProduto() {
        System.out.println("Produto: " + nome);
        System.out.println("Preço: R$ " + preco);
        System.out.println("Quantidade: " + quantidade);
    }

    public static void main(String[] args) {
        produto meuProduto = new produto("MacBook", 7000.00, 10);
        
        meuProduto.exibirProduto();

        System.out.println("Seu produto recebeu um desconto !");
        
        meuProduto.setPreco(6500.00);

        meuProduto.exibirProduto();
    }

}