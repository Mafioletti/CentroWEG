package EncapsulamentoDede;

public class carro {
    private String modelo;
    private int ano;
    private double velocidade;

    public carro(String modelo, int ano, double velocidade) {
        this.modelo = modelo;
        this.ano = ano;
        this.velocidade = velocidade;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public double getVelocidade() {
        return velocidade;
    }

    public void setVelocidade(double velocidade) {
        this.velocidade = velocidade;
    }

    public void acelerar(double valor) {
        if (valor > 0) {
            this.velocidade += valor;
        }
    }

    public void frear(double valor) {
        if (valor > 0) {
            this.velocidade -= valor;
            if (this.velocidade < 0) {
                this.velocidade = 0;
            }
        }
    }

    public void mostrarVelocidade() {
        System.out.println("Modelo: " + modelo + " " + ano + " \nVelocidade atual: " + velocidade + " km/h\n");
    }

    public static void main(String[] args) {
        carro meuCarro = new carro("Mustang", 1967, 0.0);

        meuCarro.acelerar(100.0);
        
        meuCarro.mostrarVelocidade();
        
        meuCarro.frear(30.0);
        
        meuCarro.mostrarVelocidade();
    }
}