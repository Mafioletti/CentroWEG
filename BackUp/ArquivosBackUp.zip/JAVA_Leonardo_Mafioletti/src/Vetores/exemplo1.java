package Vetores;
import java.util.Scanner;

public class exemplo1 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		int numero[] = {1, 2, 3, 4, 5, 6, 7, 8, 9};
		
		for(int i = 0; i < numero.length; i++) {
			System.out.println(numero[i]);
		}
		
		int num[] = new int [5];
		for(int cont = 0; cont < num.length; cont++) {
			System.out.println("Digite valor pra " + (cont + 1) + "ª posição");
			num[cont] = input.nextInt();
		}
		System.out.println("\nValores Digitados");
		for(int x = 0; x < 5; x++) {
			System.out.println(num[x]);
		}
	}
}
