package exemplos;
import java.util.Queue;
import java.util.LinkedList;

public class fila {

	public static void main(String[] args) {
		Queue <String> fila = new LinkedList<>();
		
		fila.add("Roberto");
		fila.add("TIM TIM");
		fila.add("Kristian");
		fila.add("Vinicius");
		
		System.out.println(fila);
		System.out.println(fila.peek());
		fila.poll();
		System.out.println(fila.peek());
	}

}
