package exemplos;
import java.util.ArrayDeque;
import java.util.Deque;
public class pilha {
	public static void main(String[] args) {
		Deque<Integer> pilha = new ArrayDeque<>();
		
		pilha.push(10);
		pilha.push(20);
		pilha.push(30);
		pilha.push(40);
		
		System.out.println(pilha);
		System.out.println(pilha.pop());
		System.out.println(pilha.peek());

	}

}
