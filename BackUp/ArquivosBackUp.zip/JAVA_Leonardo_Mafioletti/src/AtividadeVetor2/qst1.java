package AtividadeVetor2;

import java.util.Scanner;

public class qst1 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		double nota[] = new double[10];
		
		double somaMedia = 0, maiorNota = 0, alunosMaiores = 0;
		
		for(int i = 0; i < nota.length; i++) {
			System.out.println("Digite nota do aluno: ");
			nota[i] = input.nextInt();
			somaMedia += nota[i];
			
			if(nota[i] > maiorNota) {
				maiorNota = nota[i];
			}				
		}
		double media = somaMedia/nota.length;

		for(int cont = 0; cont < nota.length; cont++) {
			
			if(nota[cont] > media) {
				alunosMaiores++;
			}
		}
		System.out.println("Media da turma: "+ media + "\nNúmero de alunos superiores a média: " + alunosMaiores +"\nA maior nota: " + maiorNota);
		
		for(int y = 0; y < nota.length; y++) {
			if(nota[y] == maiorNota) {
				System.out.print("A posisão da maior nota é: " + (y + 1));
			}
		}
	}
	
}