package AtividadeVetor2;

import java.util.Scanner;

public class qst2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite a quantidade de números: ");
        int n = scanner.nextInt();

        int[] entrada = new int[n];
        int qtdPares = 0;
        int qtdImpares = 0;

        System.out.println("Digite os números:");
        for (int i = 0; i < n; i++) {
            entrada[i] = scanner.nextInt();
            if (entrada[i] % 2 == 0) {
                qtdPares++;
            } else {
                qtdImpares++;
            }
        }

        int pares[]= new int[qtdPares];
        int impares[]= new int[qtdImpares];

        int iP = 0, iI = 0;
        for (int i = 0; i < n; i++) {
            if (entrada[i] % 2 == 0) {
                pares[iP++] = entrada[i];
            } else {
                impares[iI++] = entrada[i];
            }
        }

        for (int i = 0; i < pares.length - 1; i++) {
            for (int j = 0; j < pares.length - 1 - i; j++) {
                if (pares[j] > pares[j + 1]) {
                    int temp = pares[j];
                    pares[j] = pares[j + 1];
                    pares[j + 1] = temp;
                }
            }
        }

        for (int i = 0; i < impares.length - 1; i++) {
            for (int j = 0; j < impares.length - 1 - i; j++) {
                if (impares[j] < impares[j + 1]) {
                    int temp = impares[j];
                    impares[j] = impares[j + 1];
                    impares[j + 1] = temp;
                }
            }
        }

        System.out.println("\nResultado:");
        System.out.println("Pares crescente");
        for (int p : pares) {
            System.out.print( p + " \n");
        }
        System.out.println("Impares decrescente");
        for (int im : impares) {
            System.out.print(im + " \n");
        }
        scanner.close();
    }
}