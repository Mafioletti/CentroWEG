package AtividadeVetor2;

import java.util.Scanner;

/*
3- Faça um programa que leia e monte dois vetores de números 
inteiros com 20 números cada. Depois de montados, 
gere um terceiro vetor formado pela diferença dos dois vetores lidos
, um quarto vetor formado pela soma dos dois vetores lidos e por 
último um quinto vetor formado pela multiplicação dos dois vetores 
lidos.*/

public class qst3 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		int tamanho = 3;
		
		double vet1[] = new double[tamanho];
		double vet2[] = new double[tamanho];
		double vet3[] = new double[tamanho];
		double vet4[] = new double[tamanho];
		double vet5[] = new double[tamanho];
		
		for(int i = 0; i < tamanho; i++) {
			System.out.println("Digite numero vet1: ");
			vet1[i] = input.nextInt();
			System.out.println("Digite numero vet2: ");
			vet2[i] = input.nextInt();
		}
		for(int j = 0; j < tamanho; j++) {
			vet3[j] = vet1[j] - vet2[j];
			vet4[j] = vet1[j] + vet2[j];
			vet5[j] = vet1[j] * vet2[j];
		}
		System.out.println("Vetor 3: " );
		for(int a = 0; a < tamanho; a++) {
			System.out.println("\n" + vet3[a]);
		}
		System.out.println("Vetor 4: " );
		for(int a = 0; a < tamanho; a++) {
			System.out.println("\n" + vet4[a]);
		}
		System.out.println("Vetor 5: " );
		for(int a = 0; a < tamanho; a++) {
			System.out.println("\n" + vet5[a]);
		}
	}
}