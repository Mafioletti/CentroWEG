package listaArray2;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class qst10 {

	public static void main(String[] args) {

		ArrayList<Double> Lista = new ArrayList<>();
		Scanner leia = new Scanner(System.in);

		double numero = 0;
		double soma = 0;
		do {
			System.out.println("Digite um número (-1 para sair): ");
			numero = leia.nextInt();
			if (numero != -1) {
				Lista.add(numero);
				soma += numero;
			}
		} while (numero != -1);
		System.out.println("Lista completa.");

		System.out.println("A Lista tem  " + Lista.size() + " números.");
		System.out.println("Lista: " + Lista);
		System.out.println("\nLista inversa: ");
		for (int i = Lista.size() - 1; i >= 0; i--) {
			System.out.println(Lista.get(i));
		}
		double media = soma / Lista.size();
		System.out.println("\nA soma dos números da lista é: " + soma);
		System.out.println("A média dos numeros da lista é: " + media);

		double acimaMedia = 0;
		for (double i : Lista) {
			if (i > media) {
				acimaMedia++;
			}
		}
		System.out.println("\nNúmeros acima da média: " + acimaMedia + " números.");

		double abaixoSete = 0;
		for (double i : Lista) {
			if (i < 7) {
				abaixoSete++;
			}
		}
		System.out.println("Numeros abaixo de 7: " + abaixoSete);
		
		System.out.println("\nAcabou. Tchau");
	}
}
