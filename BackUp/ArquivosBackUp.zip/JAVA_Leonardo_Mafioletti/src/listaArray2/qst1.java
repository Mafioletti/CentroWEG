package listaArray2;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class qst1 {

	public static void main(String[] args) {

		Scanner leia = new Scanner(System.in);
		ArrayList<Integer> num = new ArrayList <>();
		
		 for (int i = 0; i < 5; i++) {
	            System.out.print("Digite o " + (i + 1) + "º número: ");
	            int valor = leia.nextInt();
	            num.add(valor);
		 }
		System.out.println("Lista:");
		for(int i : num) {
			System.out.println(i);
		}
	}

}
