package listaArray2;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

		public class qst3 {
		    public static void main(String[] args) {
		        
	double mediaFinal = 0.0;	    	
		    	
		        Scanner leia = new Scanner(System.in);
		        ArrayList<Double> numeros = new ArrayList<>();

		       for( int i = 1; i <= 4; i++ ) {
		    	   System.out.println("Informe sua " + i + "º Nota: ");
		    	   Double notas = leia.nextDouble();
		    	   numeros.add(notas);
		    	   mediaFinal += notas;
		    	   
		       }
		       
		       System.out.println("Suas notas são: " + numeros );
		    		  double media = ( mediaFinal / 4);  
		    	System.out.printf("E sua média final é %.2f" , media); 
		    	
		    
		    }

}
