package listaArray2;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

		public class qst4 {
		    public static void main(String[] args) {
		        	    	
		    	
		        Scanner leia = new Scanner(System.in);
		        ArrayList<Integer> numerosPar = new ArrayList<>();
		        ArrayList<Integer> numerosImpar = new ArrayList<>();
		        
		        for(int i = 1; i <= 20; i++) {
		        	System.out.println(" informe o seu " + i + "º Número inteiro: ");
		        int numero = leia.nextInt(); 
		       
		        if(numero %2 == 0) {
		        	 numerosPar.add(numero);
		        }else {
		        	 numerosImpar.add(numero);
		        }
		        
		        }
		        System.out.println("Números Pares: " + numerosPar);
		        System.out.println("\nNúmeros Impares: " + numerosImpar);
	}

}
