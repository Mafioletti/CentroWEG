package listaArray2;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class qst8 {

	public static void main(String[] args) {

		ArrayList<Integer> Idade = new ArrayList <>();
		ArrayList<Double> Altura = new ArrayList <>();
		Scanner leia = new Scanner (System.in);
		
		double media = 0.0;
		int contagem = 0;
		
		System.out.println("Digite a Idade e a Altura dos 30 Alunos.");
		for(int i = 1; i <= 4;i++){
			System.out.println("Aluno " + i );
			System.out.println("Idade: ");
		    int idade = leia.nextInt();
		    System.out.println("Altura:");
		    double altura = leia.nextDouble();
		    Idade.add(idade);
		    Altura.add(altura);
		    media += altura;
		    
		    if(idade > 13 && altura < media / 4 ) {
		    	contagem++;
		} 
			
				
			}
		System.out.println("Tem " + contagem + " Aluno(s) com +13 Anos abaixo da Média");
	}

}
