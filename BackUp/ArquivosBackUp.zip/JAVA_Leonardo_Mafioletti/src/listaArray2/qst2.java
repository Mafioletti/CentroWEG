package listaArray2;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

		public class qst2 {
		    public static void main(String[] args) {
		        
		        Scanner leia = new Scanner(System.in);
		        ArrayList<Double> numeros = new ArrayList<>();

		        
		        for (int i = 0; i < 10; i++) {
		            System.out.print("Digite o " + (i + 1) + "º número: ");
		            double valor = leia.nextDouble();
		            numeros.add(valor);
		        }

		        System.out.println("\nNúmeros na ordem inversa:");
		        
		        // Mostra na ordem inversa (sem usar métodos prontos)
		        for (int i = numeros.size() - 1 ; i >= 0; i--) {
		            System.out.println(numeros.get(i));
		        }

		        leia.close();
		    }
		

		}
	

