package listaArray2;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

		public class qst5 {
		    public static void main(String[] args) {
		        	    	
		    	
		        Scanner leia = new Scanner(System.in);
		        ArrayList<Integer> Idade = new ArrayList<>();
		        ArrayList<Double> Altura = new ArrayList<>();
		        
		        for(int i = 1;i <= 5;i++) {
		        	System.out.println("Insira a Idade e a Altura da " + i + "º pessoa.");
		        	System.out.println("Idade:");
		        	int idade = leia.nextInt();
		        	System.out.println("Altura:");
		        	double altura = leia.nextDouble();
		        	Idade.add(idade);
		        	Altura.add(altura);
		        	
		        }
		        System.out.println("Lista das Idades inversa: ");
		        for( int i = Idade.size() - 1; i >= 0; i--) {
		        	System.out.println(Idade.get(i));
		        }System.out.println("Lista das Alturas inversa: ");
		        for( int i = Altura.size() - 1; i >= 0; i--) {
		        	System.out.println(Altura.get(i));
		    
		    }

}
}