package listaArray2;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class qst9 {

	public static void main(String[] args) {

		ArrayList<Integer> Lista = new ArrayList <>();
		ArrayList<Integer> Lista2 = new ArrayList <>();
		ArrayList<Integer> ListaTotal = new ArrayList<>();
		Scanner leia = new Scanner (System.in);
		
		for(int i = 1; i <= 10; i++ ) {
			System.out.println("Insira o " + i + "º número da Lista 1:");
			int lista1 = leia.nextInt();
			
			Lista.add(lista1);
			ListaTotal.add(lista1);
			
			System.out.println("Insira o " + i + "º número da Lista 2:");
			int lista2 = leia.nextInt();
			
			Lista2.add(lista2);
			ListaTotal.add(lista2);
			
		}
		System.out.println("Lista 1:");
		System.out.println(Lista);
		
		System.out.println("Lista 2:");
		System.out.println(Lista2);
		
		System.out.println("\nElementos juntos das listas alternadas: ");
		System.out.println(ListaTotal);
		leia.close();
	}

}
