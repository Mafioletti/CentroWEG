package listaArray2;
import java.util.Scanner;

public class qst6 {
    public static void main(String[] args) {
        
        Scanner leia = new Scanner(System.in);
        double[] medias = new double[10]; // vetor para armazenar as médias
        int contador = 0; // vai contar quantos alunos têm média >= 7
        
        // Loop para os 10 alunos
        for (int i = 0; i < 10; i++) {
            double soma = 0;
            
            System.out.println("\nAluno " + (i + 1) + ":");
            
            // Loop para as 4 notas de cada aluno
            for (int j = 0; j < 4; j++) {
                System.out.print("Digite a " + (j + 1) + "ª nota: ");
                double nota = leia.nextDouble();
                soma += nota;
            }
            
            // Calcula a média e armazena no vetor
            medias[i] = soma / 4;
        }

        // Conta quantos alunos têm média >= 7
        for (int i = 0; i < 10; i++) {
            if (medias[i] >= 7.0) {
                contador++;
            }
        }

        // Mostra o resultado
        System.out.println("\nNúmero de alunos com média maior ou igual a 7.0: " + contador);

        leia.close();
    }
}

