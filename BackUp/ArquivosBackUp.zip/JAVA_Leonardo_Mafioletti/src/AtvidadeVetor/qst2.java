package AtvidadeVetor;

import java.util.Scanner;

public class qst2 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		int numero[] = new int[6];
		
		int pares = 0, impares = 0;
		
		for(int i = 0; i < numero.length; i++) {
			System.out.println("Digite numero: ");
			numero[i] = input.nextInt();
			
			if(numero[i]%2 == 0) {
				pares++;
				System.out.println(numero[i] + " é par !");
			} else {
				impares++;
				System.out.println(numero[i] + " é ímpar !");
			}
		}
		System.out.println("Foram digitados:\n"+ pares + " números pares\n" + impares +" números ímpares");
	}
	
}