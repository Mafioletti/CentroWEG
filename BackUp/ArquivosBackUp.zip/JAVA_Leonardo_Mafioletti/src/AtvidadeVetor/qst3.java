package AtvidadeVetor;

import java.util.Scanner;

public class qst3 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		int temperatura[] = new int[6];
				
		for(int i = 0; i < temperatura.length; i++) {
			do {
				System.out.println("Digite a temperatura: ");
				temperatura[i] = input.nextInt();
				
				if(temperatura[i] >= 15 && temperatura[i] <= 40) {
					break;
				} else {
					System.out.println("digite novamente");
				}
			} while(true);
		}
		
		double maior = 0, menor = Double.MAX_VALUE, media = 0;

			for(int i = 0; i < temperatura.length; i++) {
				double temp = temperatura[i];
				
				if(temp > maior) {
					maior = temp;
				}
				if(temp < menor) {
					menor = temp;
				}
				media += temp;
		}
			media /= temperatura.length;
			
		System.out.println("A maior temperatura registrada: " + maior + "º\nA menor temperatura registrada: " + menor + "º\nTemperatura média: " + media);
	}
	
}