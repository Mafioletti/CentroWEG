package AtvidadeVetor;

import java.util.Scanner;

public class qst4 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		System.out.print("Digite a quantidade de posições: ");
		int tamanho = input.nextInt();

		String nomes[] = new String [tamanho];
		
		boolean continuar = true;

		while(continuar) {
			System.out.println("\n=====<Menu>=====\n1. Cadastrar Nome\n2. Pesquisar nome\n3. Listar todos os nomes\n0. Sair do programa");
			int opcao = input.nextInt();
			
			switch(opcao) {
				case 1:
					nomes = CadastrarNome(input, nomes);
					break;
				case 2:
					PesquisarNome(input, nomes);
					break;
				case 3:
					ListarNomes(nomes);
					break;
				case 0:
					continuar = false;
					break;
				default:
					System.out.println("\nOpção Inválida\n");
			}
		}
	}
	public static String[] CadastrarNome(Scanner i, String n[]) {
		int pOcupadas = PosicoesOcupadas(n);

		if(pOcupadas == n.length) {
			return n;
		}
		System.out.print("\nDigite o nome: ");
			n[pOcupadas] = i.next();
				return n;
	}
	public static void ListarNomes(String n[]) {
		for(int i = 0; i < n.length; i++) {
			if(n[i] != null) {				
				System.out.println("#" + i + " " + n[i]);
			}
		}
	}
	public static void PesquisarNome(Scanner i, String n[]) {
		System.out.print("Digite o nome a pesquisar: ");
		String nome = i.next().toLowerCase();

		for(int j = 0; j < n.length; j++) {
			if(n[j] != null) {
				if(n[j].toLowerCase().contains(nome)) {
					System.out.println("#" + j + " " + n[j]);
				}
			}
		}
	}
	public static int PosicoesOcupadas(String n[]) {
		int cont = 0;
		for(int i = 0; i < n.length; i ++) {
			if(n[i] != null) {
				cont++;
			}
		}
		return cont;
	}
}