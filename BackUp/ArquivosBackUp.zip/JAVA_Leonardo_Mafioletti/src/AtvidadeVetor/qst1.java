package AtvidadeVetor;

import java.util.Scanner;

public class qst1 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		int tamanho = 10;
		
		double totalVendas[] = new double [tamanho];
		double percentual[] = new double [tamanho];
		double pagamento[] = new double [tamanho];
		double somaTotal = 0;
		double maior = 0, menor = Double.MAX_VALUE;
		
		String nome[] = new String[tamanho];
		String nomeMaior = new String();
		String nomeMenor = new String();
		
		for(int cont = 0; cont < totalVendas.length; cont++) {
			System.out.println("Digite o nome do vendedor: ");
			nome[cont] = input.next();
			System.out.println("Digite o total de vendas: ");
			totalVendas[cont] = input.nextDouble();
			System.out.println("Digite o percentual: ");
			percentual[cont] = input.nextDouble();
			somaTotal += totalVendas[cont]; 
		}
		for(int cont = 0; cont < totalVendas.length; cont++) {
			pagamento[cont] = (totalVendas[cont] * percentual[cont] / 100);
			System.out.println("O vendedor "+ nome[cont] + " irá receber R$ " + pagamento[cont]);

			if(pagamento[cont] > maior) {
				maior = pagamento[cont];
				nomeMaior = nome[cont];
			}
			if(pagamento[cont] < menor) {
				menor = pagamento[cont];
						nomeMenor = nome[cont];
			}
		}
		
			System.out.println("O total de vendas: " + somaTotal);
			System.out.println(nomeMaior + "ganhou " + maior);
			System.out.println(nomeMenor + " ganhou "+ menor);
		}
	}

