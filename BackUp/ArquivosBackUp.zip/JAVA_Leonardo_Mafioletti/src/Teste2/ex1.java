package Teste2;

import java.util.*;

public class ex1 {
	public static void main(String[] args) {
		int num;
		double num2;
		char nome;
		String sobrenome = new String();
		Scanner input = new Scanner(System.in);

		System.out.println("Digite Valor: ");
		num = input.nextInt();

		if (num > 5) {
			System.out.println("Maior");
		} else if (num == 5) {
			System.out.println("Igual");
		} else {
			System.out.println("Menor");
		}

		switch (num) {
		case 1:
			System.out.println("Primeira Opção");
			break;
		case 2:
			System.out.println("Segunda Opção");
			break;
		default:
			System.out.println("Erro");
		}

		/*
		 * while(num > 2) { System.out.println("Digite valor: "); num = input.nextInt();
		 */

		do {
			System.out.println("Digite valor pro Do while: ");
			num = input.nextInt();
		} while (num > 2);

		for (int i = 0; i < 10; i++) {
			System.out.println(num);
		}
		System.out.println(Oi());

	}

	public static int Oi() {
		int numero = 6;
		System.out.println("oi");
		return numero;
	}
}