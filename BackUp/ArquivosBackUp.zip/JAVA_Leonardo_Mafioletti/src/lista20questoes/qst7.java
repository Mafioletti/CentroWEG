package lista20questoes;

import java.util.Random;
import java.util.Scanner;

public class qst7 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int[] numeros = new int[10];
        Random gerador = new Random();
        
        for (int i = 0; i < numeros.length; i++) {
            numeros[i] = gerador.nextInt(30);
        }
        
        System.out.print("Digite um número: ");
        int alvo = sc.nextInt();

        int posicaoEncontrada = -1;

        for (int i = 0; i < numeros.length; i++) {
            if (numeros[i] == alvo) {
                posicaoEncontrada = i;
                break;
            }
        }
        if (posicaoEncontrada != -1) {
            System.out.println("Número encontrado no índice: " + posicaoEncontrada);
        } else {
            System.out.println("Número não encontrado.");
        }
    }
}