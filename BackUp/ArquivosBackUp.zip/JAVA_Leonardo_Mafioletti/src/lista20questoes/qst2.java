package lista20questoes;
import java.util.Scanner;
import java.util.Arrays;

public class qst2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int tamanho = 5;
		
		int codigo[] = new int[tamanho];
		double preco[] = new double[tamanho];
		double precoMaior[] = new double[tamanho];
		
		for(int i = 0; i < codigo.length; i++) {
			System.out.println("Digite o código do artigo: ");
			codigo[i] = sc.nextInt();
			System.out.println("Digite o preço de venda: ");
			preco[i] = sc.nextDouble();
			precoMaior[i] = preco[i];
		}
//		System.out.println(Arrays.toString(precoMaior));
		Arrays.sort(precoMaior);
		double maior = precoMaior[precoMaior.length - 1];
		double segundo = precoMaior[precoMaior.length - 2];
		double terceiro = precoMaior[precoMaior.length - 3];
		
		int codMaior = 0, codSegundo = 0, codTerceiro = 0;

		for(int i = 0; i < preco.length; i++) {
			if(maior == preco[i]) {
				codMaior = codigo[i];
			}
			else if(segundo == preco[i]) {
				codSegundo = codigo[i];
			}
			else if(terceiro == preco[i]) {
				codTerceiro = codigo[i];
			}
		}
		System.out.println("O maior valor é: " + maior + " com o código: " + codMaior);
		System.out.println("O segundo maior valor é: " + segundo + " com o código: " + codSegundo);
		System.out.println("O terceiro maior valor é: " + terceiro + " com o código: " + codTerceiro);
	}
}