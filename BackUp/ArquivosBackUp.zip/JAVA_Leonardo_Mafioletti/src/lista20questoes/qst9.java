package lista20questoes;
import java.util.Scanner;

public class qst9 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int vetor[] = new int[10];
        int menores = 0;
        int repetidos = 0;

        for (int i = 0; i < 10; i++) {
            System.out.print("Digite o " + (i + 1) + "º número: ");
            vetor[i] = sc.nextInt();
        }
        System.out.print("\nDigite o valor de referência: ");
        int referencia = sc.nextInt();

        System.out.println("\nNúmeros maiores que a referência:");
        
        for (int i = 0; i < vetor.length; i++) {
            if (vetor[i] > referencia) {
                System.out.print(vetor[i] + " ");
            }
            if (vetor[i] < referencia) {
                menores++;
            }
            if (vetor[i] == referencia) {
                repetidos++;
            }
        }
        System.out.println("\n\nQuantidade de números menores que a referência: " + menores);
        System.out.println("O valor de referência aparece " + repetidos + " vezes no vetor.");
    }
}