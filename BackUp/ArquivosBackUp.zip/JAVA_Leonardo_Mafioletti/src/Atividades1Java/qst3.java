package Atividades1Java;

import java.util.Scanner;

public class qst3 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		System.out.println("Digite seu salário: ");
		int salario = input.nextInt();

		double reajuste = salario + ((salario * 23.75) / 100);

		System.out.println("Salário final é: " + reajuste);

		input.close();
	}
}
