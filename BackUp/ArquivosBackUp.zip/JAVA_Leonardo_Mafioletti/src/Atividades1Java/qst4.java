package Atividades1Java;

import java.util.Scanner;

public class qst4 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		System.out.println("Digite o valor da prestação: ");
		double prestacao = input.nextDouble();
		System.out.println("Digite a taxa: ");
		double taxa = input.nextDouble();
		System.out.println("Digite o número de dias atrasados: ");
		double dias = input.nextDouble();

		double prestacaoAtrasada = prestacao + (prestacao * (taxa / 100) * dias);

		System.out.println("O valor final das prestações é: " + prestacaoAtrasada);

		input.close();
	}
}
