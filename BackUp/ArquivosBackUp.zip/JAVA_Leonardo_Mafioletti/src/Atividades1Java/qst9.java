package Atividades1Java;

import java.util.Scanner;

public class qst9 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		double altura, maiorAltura = 0, media, soma = 0, maiorQueDois = 0;

		for (int i = 1; i <= 20; i++) {
			System.out.println("Digite a altura em metros da " + i + "ª pessoa");
			altura = input.nextDouble();

			soma += altura; // pra media

			if (maiorAltura < altura) { // maior altura
				maiorAltura = altura;
			}

			if (altura > 2) {
				maiorQueDois++;
			}
		}
		media = soma / 20;
		System.out.println("A maior altura do grupo é: " + maiorAltura + "\nA média das alturas é: " + media
				+ "\nE a quantidade de pessoas com a altura superior a 2 metros é: " + maiorQueDois);

		input.close();
	}
}
