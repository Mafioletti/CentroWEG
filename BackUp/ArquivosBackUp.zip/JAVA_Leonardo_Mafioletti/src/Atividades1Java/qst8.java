package Atividades1Java;

import java.util.Scanner;

public class qst8 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		int player1 = 18, player2 = 18;
		int ponto;
		boolean fimPartida = false;

		while (fimPartida != true) {
			int diferenca = player1 - player2;

			if (player1 >= 21 && diferenca >= 2) {
				System.out.println("Player 1 vencedor");
				fimPartida = true;
			} else if (player2 >= 21 && diferenca >= 2) {
				System.out.println("Player 2 vencedor");
				fimPartida = true;
			} else {
				System.out.println("Digite quem fez o ponto 1 ou 2: ");
				ponto = input.nextInt();

				if (diferenca < 0) {
					diferenca *= -1;
				}
				if (ponto == 1) {
					player1++;
				} else if (ponto == 2) {
					player2++;
				}
			}
		}
		System.out.println("Placar:\nPlayer1: " + player1 + "\nPlayer2: " + player2);

		input.close();
	}
}
