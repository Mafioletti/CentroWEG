package Atividades1Java;

import java.util.Scanner;

public class qst5 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		double soma = 0, contador = 0;

		for (int cont = 1; cont <= 4; cont++) {
			System.out.println("Digite sua " + cont + "ª nota");
			soma += input.nextDouble();
			contador++;
		}

		double media = soma / contador;

		System.out.println("A média das notas é : " + media);

		input.close();
	}
}
