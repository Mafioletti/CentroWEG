package Atividades1Java;

import java.util.Scanner;

public class qst10 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		int num, positivos = 0, negativos = 0, somaFinal = 0;

		do {
			System.out.println("Digite numero: ");
			num = input.nextInt();

			if (num > 0) {
				positivos += num;
			} else if (num < 0) {
				negativos += num;
			}
			somaFinal += num;
		} while (num != 0);

		System.out.println("A soma dos positivos: " + positivos + "\nA soma dos negativos: " + negativos
				+ "\nA soma total: " + somaFinal);

		input.close();
	}
}