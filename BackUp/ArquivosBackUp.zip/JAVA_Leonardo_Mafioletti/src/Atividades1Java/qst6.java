package Atividades1Java;

public class qst6 {
	public static void main(String[] args) {
		double alturaJoao = 1.50;
		double alturaZe = 1.10;
		int contAnos = 0;

		while (alturaJoao > alturaZe) {
			alturaJoao += 0.02;
			alturaZe += 0.03;
			contAnos++;
		}
		System.out.println("Foram necessários " + contAnos + " anos para Zé ficar maior que João");
	}
}
