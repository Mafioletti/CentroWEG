package Atividades1Java;

import java.util.Scanner;

public class qst2 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		System.out.println("Digite a temperatura em graus celsius");
		double celsius = input.nextDouble();
		double tempFahrenheit;

		tempFahrenheit = (celsius * 1.8) + 32;

		String formatado = String.format("%.2f", tempFahrenheit);

		System.out.println("A temperatura em fahrenheit: " + formatado);

		input.close();
	}
}
