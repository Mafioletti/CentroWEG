package Atividades1Java;

public class qst7 {
	public static void main(String[] args) {
		double pais1 = 90_000_000;
		double pais2 = 140_000_000;
		int contAnos = 0;

		while (pais2 > pais1) {
			pais1 *= 1.035;
			pais2 *= 1.01;
			contAnos++;
		}
		System.out.println("Foram necessários " + contAnos + " anos pro pais1 ter mais população que o pais2");
	}
}
