package Atividades1Java;

import java.util.Scanner;

public class qst1 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		System.out.println("Digite a temperatura em graus fahrenheit");
		double fahrenheit = input.nextDouble();
		double tempCelsius;

		tempCelsius = (fahrenheit - 32) / 1.8;

		String formatado = String.format("%.2f", tempCelsius);

		System.out.println("A temperatura em celsius: " + formatado + "ºC");

		input.close();
	}
}
