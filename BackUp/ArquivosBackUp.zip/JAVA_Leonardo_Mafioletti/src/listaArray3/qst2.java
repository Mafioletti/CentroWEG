package listaArray3;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class qst2 {

	public static void main(String[] args) {

		ArrayList<Integer> Lista = new ArrayList <>();
		Scanner leia = new Scanner (System.in);
		
		int quadrado = 0;
		int soma = 0;
		System.out.println("Digite 10 números inteiros");
		for(int i = 1;i <= 10;i++) {
			int num = leia.nextInt();
			
			quadrado = num * num;
			soma += quadrado;
			Lista.add(soma);
		}
		System.out.println("Lista da soma dos números ao quadrado");
		System.out.println(Lista);
		leia.close();
	}

}
