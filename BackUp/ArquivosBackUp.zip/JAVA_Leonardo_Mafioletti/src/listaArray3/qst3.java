package listaArray3;
import java.util.Scanner;

public class qst3 {
    public static void main(String[] args) {
        
        Scanner leia = new Scanner(System.in);
        int[] numeros = new int[5]; // vetor com 5 posições
        int soma = 0;
        int multiplicacao = 1; // começa com 1, porque será usado em produto

        // Leitura dos números
        for (int i = 0; i < 5; i++) {
            System.out.print("Digite o " + (i + 1) + "º número: ");
            numeros[i] = leia.nextInt();
        }

        
        

        // Mostra os números digitados
        System.out.println("\nNúmeros digitados:");
        for (int i = 0; i < 5; i++) {
            System.out.print(numeros[i] + " ");
        }
        leia.close();
	}

}
