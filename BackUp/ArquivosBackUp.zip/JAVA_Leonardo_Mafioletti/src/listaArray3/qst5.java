package listaArray3;
import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;


public class qst5 {

	public static void main(String[] args) {

		ArrayList<Integer> Windows = new ArrayList <>();
		ArrayList<Integer> Mac = new ArrayList <>();
		ArrayList<Integer> Unix = new ArrayList <>();
		ArrayList<Integer> Linux = new ArrayList <>();
		ArrayList<Integer> Netware = new ArrayList <>();
		ArrayList<Integer> Outro = new ArrayList <>();
		
		Scanner leia = new Scanner (System.in);
		
		int contador = 0;
		int voto = 0;
		do {
			System.out.println("Qual o melhor sistema operacional para uso em servidores?");
			System.out.println("1- Windows Server ");
			System.out.println("2- Unix");
			System.out.println("3- Linux");
			System.out.println("4- Netware");
			System.out.println("5- Mac OS");
			System.out.println("6- Outro");
			 voto = leia.nextInt();
			
			if(voto == 1) {
				Windows.add(voto);
			}else if(voto == 2) {
				Unix.add(voto);
			}else if(voto == 3) {
				Linux.add(voto);
			}else if(voto == 4) {
				Netware.add(voto);
			}else if(voto == 5) {
				Mac.add(voto);
			}else if(voto == 6) {
				Outro.add(voto);
			}
			contador++;
		}while(voto >= 1 && voto <= 6);
		System.out.println(" Votação Encerrada");
		
		System.out.println("Sistema Operacional \tVotos \t%");
		System.out.println("------------------- \t----- \t--");
		System.out.printf("Windows Server \t%.1f /n", Windows.size());
		System.out.printf("Unix \t%.1f /n", Unix.size());
		System.out.printf("Linux \t%.1f /n", Linux.size());
		System.out.printf("Netware \t%.1f /n", Netware.size());
		System.out.printf("Mac OS \t%.1f /n", Mac.size());
		System.out.printf("Outro \t%.1f /n", Outro.size());
	}

}
