package listaArray3;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class qst1 {

	public static void main(String[] args) {

		ArrayList<Integer> Lista = new ArrayList <>();
		Scanner leia = new Scanner (System.in);
		
		int soma = 0;
		int multi = 1;
		int lista = 0;
		
		System.out.println("Digite 5 números inteiros: ");
		for(int i = 1;i <= 5;i++) {
			int num = leia.nextInt();
			
			soma += num;
			multi *= num;
			Lista.add(num);
		}
		System.out.println(Lista);
		System.out.println("Soma:");
		System.out.println(soma);
		System.out.println("Multiplicação:");
		System.out.println(multi);
		
		leia.close();
	}

}
