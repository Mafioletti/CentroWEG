package listaArray3;
import java.util.ArrayList;
import java.util.Scanner;

public class qst4 {
    public static void main(String[] args) {
        Scanner leia = new Scanner(System.in);
        
        ArrayList<Integer> contadores = new ArrayList<>();
        for (int i = 0; i < 9; i++) {
            contadores.add(0);
        }

        System.out.print("Quantos vendedores deseja cadastrar? ");
        int qtd = leia.nextInt();

        for (int i = 0; i < qtd; i++) {
            System.out.print("Digite as vendas brutas do vendedor " + (i + 1) + ": ");
            double vendas = leia.nextDouble();

            double salario = 200 + (vendas * 0.09);
            
            
            int indice = (int)((salario - 200) / 100);
            if (indice > 8) indice = 8; 

            contadores.set(indice, contadores.get(indice) + 1);
        }

      
        System.out.println("\nDistribuição de salários:");
        String[] faixas = {
            "$200 - $299",
            "$300 - $399",
            "$400 - $499",
            "$500 - $599",
            "$600 - $699",
            "$700 - $799",
            "$800 - $899",
            "$900 - $999",
            "$1000 ou mais"
        };

        for (int i = 0; i < contadores.size(); i++) {
            System.out.println(faixas[i] + ": " + contadores.get(i) + " vendedor(es)");
        }

        leia.close();
    }
}
